__author__ = 'Christian Ludwig (C.Ludwig@bham.ac.uk)'
__credits__ = 'Christian Ludwig (C.Ludwig@bham.ac.uk)'
__version__ = '0.7.23'
__license__ = 'GPLv3'
