import metabolabpy.__init__ as ml_version
__author__ = 'Christian Ludwig (C.Ludwig@bham.ac.uk)'
__credits__ = 'Christian Ludwig (C.Ludwig@bham.ac.uk)'
__version__ = ml_version.__version__
__license__ = 'GPLv3'
